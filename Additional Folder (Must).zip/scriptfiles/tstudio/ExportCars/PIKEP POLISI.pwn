//Vehicle Exported with Texture Studio By: [uL]Pottus/////////////////////////////////////////////////////////////
//////////////////////////////////////////////////and Crayder/////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <a_samp>
#include <streamer>

new carvid;

public OnFilterScriptInit()
{ 
    new tmpobjid;

    carvid = CreateVehicle(422,1322.080,1564.819,10.820,300.142,84,127,-1,1);

    tmpobjid = CreateDynamicObject(19483,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "Bow_Abpave_Gen", 0);
    SetDynamicObjectMaterialText(tmpobjid, 0, "POLISI", 130, "Ariel", 100, 0, -15616, 0, 1);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, -0.031, 1.582, 0.277, -0.300, -87.499, 89.299);
    tmpobjid = CreateDynamicObject(19620,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, 0.000, 0.000, 0.779, 0.000, 0.000, 0.000);
    tmpobjid = CreateDynamicObject(1897,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "Bow_Abpave_Gen", -15616);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, -0.982, -1.256, -0.029, 88.800, -3.199, 3.999);
    tmpobjid = CreateDynamicObject(1897,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "Bow_Abpave_Gen", -15616);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, 0.982, -1.256, -0.029, 88.800, 3.199, -3.999);
} 

public OnFilterScriptExit()
{ 
    DestroyVehicle(carvid);
} 

public OnVehicleSpawn(vehicleid)
{ 
    if(vehicleid == carvid)
    { 
    } 
} 
