//Vehicle Exported with Texture Studio By: [uL]Pottus/////////////////////////////////////////////////////////////
//////////////////////////////////////////////////and Crayder/////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <a_samp>
#include <streamer>

new carvid;

public OnFilterScriptInit()
{ 
    new tmpobjid;

    carvid = CreateVehicle(431,1491.287,1396.303,10.828,165.123,2,16,-1,0);

    tmpobjid = CreateDynamicObject(7313,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterialText(tmpobjid, 0, "{ffffff} BUS PANDA KOTA NEGERIKU", 110, "Ariel", 20, 0, 0, 1, 1);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, -1.263, 0.195, 0.690, 0.000, 0.000, -89.900);
    tmpobjid = CreateDynamicObject(7313,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterialText(tmpobjid, 0, "{ffffff} BUS PANDA KOTA NEGERIKU", 110, "Ariel", 20, 0, 0, 1, 1);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, 1.263, 0.195, 0.690, 0.000, 0.000, 89.900);
} 

public OnFilterScriptExit()
{ 
    DestroyVehicle(carvid);
} 

public OnVehicleSpawn(vehicleid)
{ 
    if(vehicleid == carvid)
    { 
    } 
} 
