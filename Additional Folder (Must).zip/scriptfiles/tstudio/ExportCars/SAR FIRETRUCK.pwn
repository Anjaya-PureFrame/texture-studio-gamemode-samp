//Vehicle Exported with Texture Studio By: [uL]Pottus/////////////////////////////////////////////////////////////
//////////////////////////////////////////////////and Crayder/////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <a_samp>
#include <streamer>

new carvid;

public OnFilterScriptInit()
{ 
    new tmpobjid;

    carvid = CreateVehicle(407,-207.167,232.641,12.072,301.289,3,25,-1,0);

    tmpobjid = CreateDynamicObject(2714,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ferry_build14", -65536);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, 1.230, -2.039, 0.170, 0.000, 0.000, 90.000);
    tmpobjid = CreateDynamicObject(2714,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ferry_build14", -65536);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, -1.230, -2.039, 0.170, 0.000, 0.000, -90.000);
    tmpobjid = CreateDynamicObject(19483,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ferry_build14", 0);
    SetDynamicObjectMaterialText(tmpobjid, 0, "{FFFFFF}SAR", 100, "Ariel", 50, 0, 0, 0, 1);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, 1.249, -2.019, 0.150, 0.000, 0.000, 0.000);
    tmpobjid = CreateDynamicObject(19483,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ferry_build14", 0);
    SetDynamicObjectMaterialText(tmpobjid, 0, "{FFFFFF}SAR", 100, "Ariel", 50, 0, 0, 0, 1);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, -1.249, -2.019, 0.150, 0.000, 0.000, 180.000);
    tmpobjid = CreateDynamicObject(19797,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, 0.289, 4.180, 0.320, 0.000, 0.000, 180.000);
    tmpobjid = CreateDynamicObject(19797,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, -0.289, 4.180, 0.320, 0.000, 0.000, -180.000);
} 

public OnFilterScriptExit()
{ 
    DestroyVehicle(carvid);
} 

public OnVehicleSpawn(vehicleid)
{ 
    if(vehicleid == carvid)
    { 
    } 
} 
