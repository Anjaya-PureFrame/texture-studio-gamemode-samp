//Vehicle Exported with Texture Studio By: [uL]Pottus/////////////////////////////////////////////////////////////
//////////////////////////////////////////////////and Crayder/////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <a_samp>
#include <streamer>

new carvid;

public OnFilterScriptInit()
{ 
    new tmpobjid;

    carvid = CreateVehicle(426,1364.583,1590.285,10.820,106.914,123,-1,-1,1);

    tmpobjid = CreateDynamicObject(19483,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "Bow_Abpave_Gen", 0);
    SetDynamicObjectMaterialText(tmpobjid, 0, "POLISI", 130, "Ariel", 100, 1, -15616, 0, 0);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, -0.549, 2.069, 0.212, 0.299, -81.400, 88.999);
    tmpobjid = CreateDynamicObject(19483,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "Bow_Abpave_Gen", 0);
    SetDynamicObjectMaterialText(tmpobjid, 0, "PATROLI", 130, "Ariel", 70, 1, -15616, 0, 0);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, 0.647, -2.820, 0.211, -0.199, -80.799, -90.000);
    tmpobjid = CreateDynamicObject(19620,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, 0.020, -0.500, 0.890, 0.000, 0.000, 0.000);
} 

public OnFilterScriptExit()
{ 
    DestroyVehicle(carvid);
} 

public OnVehicleSpawn(vehicleid)
{ 
    if(vehicleid == carvid)
    { 
    } 
} 
