//Vehicle Exported with Texture Studio By: [uL]Pottus/////////////////////////////////////////////////////////////
//////////////////////////////////////////////////and Crayder/////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <a_samp>
#include <streamer>

new carvid;

public OnFilterScriptInit()
{ 
    new tmpobjid;

    carvid = CreateVehicle(468,-247.628,110.262,1.099,218.052,0,0,-1,0);

    tmpobjid = CreateDynamicObject(19483,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ferry_build14", 0);
    SetDynamicObjectMaterialText(tmpobjid, 0, "{ffff00}POLRI", 130, "Ariel", 22, 0, 0, 0, 1);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, -0.199, 0.236, 0.178, 37.099, -1.299, 183.800);
    tmpobjid = CreateDynamicObject(19483,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    SetDynamicObjectMaterial(tmpobjid, 0, 10101, "2notherbuildsfe", "ferry_build14", 0);
    SetDynamicObjectMaterialText(tmpobjid, 0, "{ffff00}POLRI", 130, "Ariel", 22, 0, 0, 0, 1);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, 0.199, 0.236, 0.178, -37.800, 1.299, -3.800);
    tmpobjid = CreateDynamicObject(19797,0.0,0.0,-1000.0,0.0,0.0,0.0,-1,-1,-1,300.0,300.0);
    AttachDynamicObjectToVehicle(tmpobjid, carvid, -0.010, 0.450, 0.576, -23.000, -1.600, 179.599);
} 

public OnFilterScriptExit()
{ 
    DestroyVehicle(carvid);
} 

public OnVehicleSpawn(vehicleid)
{ 
    if(vehicleid == carvid)
    { 
    } 
} 
